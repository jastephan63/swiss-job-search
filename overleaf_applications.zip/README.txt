Jake Stephan - application sources for Overleaf
================================================

Every file is self-contained: article class, Latin Modern fonts, no .cls or .sty
of its own and no external font files. Compile with pdfLaTeX, which is Overleaf's
default. Run twice so hyperref settles the layout.

  cv/               two-page CVs, one per application
  cover_letters/    one-page letters, matching filenames

House rules baked into every file (keep them):
  - no em-dashes, only normal hyphens in compounds
  - no eszett, ever: Strasse, Freundliche Grüsse, gross
  - no bold in cover-letter bodies
  - single column, no graphics, no photo (ATS-safe)

Two traps, both learned the hard way:
  - Never use \enlargethispage to force a page fit. It pushes content BELOW the
    page edge: the text still extracts and the page count still looks right, but
    it is not on the paper. Cut content or add a page instead.
  - A placeholder in square brackets at the start of a line after a bare \\ gets
    swallowed as \\'s optional spacing argument. Brace it: {[Phone]}.

Pages: two for Swiss employers (cantonal, federal, research, SME). One page only
for management consulting.
